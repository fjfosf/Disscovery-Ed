import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { BookOpen, Link2 } from 'lucide-react';
import ThemeToggle from './ThemeToggle';

const Header: React.FC = () => {
  const location = useLocation();
  
  return (
    <header className="sticky top-0 z-10 bg-white dark:bg-gray-900 shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <BookOpen className="text-blue-600 dark:text-blue-500" size={28} />
          <h1 className="text-xl font-semibold text-gray-900 dark:text-white">EduSummarizer</h1>
        </div>
        <div className="flex items-center space-x-4">
          <nav>
            <ul className="flex space-x-6">
              <li>
                <Link
                  to="/"
                  className={`flex items-center space-x-1 ${
                    location.pathname === '/'
                      ? 'text-blue-600 dark:text-blue-500'
                      : 'text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-500'
                  } transition-colors`}
                >
                  <BookOpen size={16} />
                  <span>Text</span>
                </Link>
              </li>
              <li>
                <Link
                  to="/url"
                  className={`flex items-center space-x-1 ${
                    location.pathname === '/url'
                      ? 'text-blue-600 dark:text-blue-500'
                      : 'text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-500'
                  } transition-colors`}
                >
                  <Link2 size={16} />
                  <span>URL</span>
                </Link>
              </li>
              <li>
                <Link
                  to="/about"
                  className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-500 transition-colors"
                >
                  About
                </Link>
              </li>
            </ul>
          </nav>
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
};

export default Header;