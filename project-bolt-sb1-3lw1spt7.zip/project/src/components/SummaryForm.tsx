import React, { useState } from 'react';
import { FileText, Link, Loader2, AlertCircle } from 'lucide-react';

interface SummaryFormProps {
  onSubmit: (text: string, isUrl: boolean) => void;
  isLoading: boolean;
}

const SummaryForm: React.FC<SummaryFormProps> = ({ onSubmit, isLoading }) => {
  const [text, setText] = useState('');
  const [isUrl, setIsUrl] = useState(false);
  const [clipboardError, setClipboardError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(text.trim(), isUrl);
  };

  const handlePaste = async () => {
    // Clear any previous errors
    setClipboardError(null);

    // Check if clipboard API is supported
    if (!navigator.clipboard?.readText) {
      setClipboardError('Clipboard access is not supported in your browser');
      return;
    }

    try {
      const clipboardText = await navigator.clipboard.readText();
      setText(clipboardText);
      setIsUrl(clipboardText.startsWith('http'));
    } catch (err) {
      if (err instanceof Error) {
        if (err.name === 'NotAllowedError') {
          setClipboardError('Please allow clipboard access in your browser settings to use this feature');
        } else {
          setClipboardError('Failed to read from clipboard. Please try copying and pasting manually');
        }
      }
      console.error('Failed to read clipboard:', err);
    }
  };

  const handleInputChange = (value: string) => {
    setText(value);
    setIsUrl(value.trim().startsWith('http'));
    // Clear any clipboard errors when user starts typing
    if (clipboardError) setClipboardError(null);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="space-y-4">
        <div className="flex flex-col">
          <div className="flex justify-between items-center mb-2">
            <label htmlFor="content" className="text-lg font-medium text-gray-900 dark:text-gray-100">
              Discovery Education Content
            </label>
            <button
              type="button"
              onClick={handlePaste}
              className="text-sm text-blue-600 dark:text-blue-500 hover:text-blue-800 dark:hover:text-blue-400 flex items-center gap-1"
            >
              <FileText size={16} />
              Paste from clipboard
            </button>
          </div>
          
          {clipboardError && (
            <div className="mb-3 p-3 rounded-lg bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 text-sm flex items-start gap-2">
              <AlertCircle size={16} className="mt-0.5 flex-shrink-0" />
              <span>{clipboardError}</span>
            </div>
          )}

          <div className="relative">
            <textarea
              id="content"
              value={text}
              onChange={(e) => handleInputChange(e.target.value)}
              placeholder={isUrl ? "Paste a Discovery Education URL here..." : "Paste your Discovery Education content here..."}
              className="w-full h-64 p-4 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-gray-100 resize-none transition-all"
              required
            />
            <div className="absolute top-3 right-3">
              {isUrl && (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                  <Link size={12} className="mr-1" />
                  URL Mode
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex justify-between items-center">
          <div className="text-sm text-gray-600 dark:text-gray-400">
            {text.trim().length > 0 && !isUrl && (
              <>
                Word count: {text.trim().split(/\s+/).filter(Boolean).length}
              </>
            )}
          </div>
          <button
            type="submit"
            disabled={isLoading || !text.trim()}
            className={`px-6 py-2.5 rounded-lg bg-blue-600 text-white font-medium flex items-center space-x-2 transition-all
              ${isLoading ? 'opacity-80 cursor-not-allowed' : 'hover:bg-blue-700 active:bg-blue-800'}
              ${!text.trim() && 'opacity-50 cursor-not-allowed'}`}
          >
            {isLoading ? (
              <>
                <Loader2 size={18} className="animate-spin" />
                <span>Summarizing...</span>
              </>
            ) : (
              <span>Summarize</span>
            )}
          </button>
        </div>
      </div>
    </form>
  );
};

export default SummaryForm;