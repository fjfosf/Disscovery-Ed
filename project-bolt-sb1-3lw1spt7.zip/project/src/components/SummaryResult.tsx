import React, { useState } from 'react';
import { Summary } from '../types';
import { Copy, Check, Clock, Book, Link } from 'lucide-react';

interface SummaryResultProps {
  summary: Summary;
  onReset: () => void;
}

const SummaryResult: React.FC<SummaryResultProps> = ({ summary, onReset }) => {
  const [copied, setCopied] = useState(false);
  
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(summary.summarizedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };
  
  return (
    <div className="w-full animate-fadeIn">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 border border-gray-200 dark:border-gray-700">
        <div className="flex justify-between items-start mb-4">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Summary</h2>
          <div className="flex space-x-2">
            <button
              onClick={handleCopy}
              className="p-2 rounded-md text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              aria-label="Copy to clipboard"
            >
              {copied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
            </button>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-4 mb-4">
          <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
            <Clock size={16} className="mr-1" />
            <span>Generated on {formatDate(summary.timestamp)}</span>
          </div>
          <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
            <Book size={16} className="mr-1" />
            <span>{summary.wordCount} words • {summary.readingTime} min read</span>
          </div>
          {summary.sourceUrl && (
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
              <Link size={16} className="mr-1" />
              <a
                href={summary.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-blue-600 dark:hover:text-blue-400 underline"
              >
                Source
              </a>
            </div>
          )}
        </div>
        
        <div className="prose dark:prose-invert prose-sm sm:prose-base lg:prose-lg max-w-none mb-6">
          <p className="text-gray-800 dark:text-gray-200 whitespace-pre-line">
            {summary.summarizedText}
          </p>
        </div>
        
        <div className="flex justify-between items-center pt-4 border-t border-gray-200 dark:border-gray-700">
          <button
            onClick={onReset}
            className="px-4 py-2 text-blue-600 dark:text-blue-500 hover:text-blue-800 dark:hover:text-blue-400 transition-colors"
          >
            Summarize another text
          </button>
          
          <div className="flex space-x-2">
            <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition-colors">
              Save
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SummaryResult;