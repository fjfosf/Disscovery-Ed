export interface Summary {
  id: string;
  originalText: string;
  summarizedText: string;
  timestamp: number;
  wordCount: number;
  readingTime: number;
  sourceUrl: string | null;
}

export type Theme = 'light' | 'dark';