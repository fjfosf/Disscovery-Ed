import { Summary } from '../types';
import * as cheerio from 'cheerio';

const extractContentFromUrl = async (url: string): Promise<string> => {
  try {
    const response = await fetch(url);
    const html = await response.text();
    const $ = cheerio.load(html);
    
    // Remove unnecessary elements
    $('script').remove();
    $('style').remove();
    $('nav').remove();
    $('header').remove();
    $('footer').remove();
    
    // Extract main content (adjust selectors based on Discovery Education's structure)
    const mainContent = $('.main-content, article, .content-area').text();
    return mainContent.trim();
  } catch (error) {
    throw new Error('Failed to extract content from URL');
  }
};

export const summarizeText = async (input: string, isUrl: boolean = false): Promise<Summary> => {
  let text = input;
  
  if (isUrl) {
    text = await extractContentFromUrl(input);
  }
  
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 1500));

  // Get word count
  const words = text.split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  
  // Calculate reading time (average reading speed: 200 words per minute)
  const readingTime = Math.ceil(wordCount / 200);

  // Simple summarization logic (in production, this would be replaced with a proper API call)
  let summarizedText = '';
  
  // For demo purposes, extract first sentence from each paragraph
  const paragraphs = text.split('\n').filter(Boolean);
  
  if (paragraphs.length > 0) {
    const sentences = paragraphs.map(p => {
      const match = p.match(/^.*?[.!?](?:\s|$)/);
      return match ? match[0].trim() : p.slice(0, 100) + '...';
    });
    
    summarizedText = sentences.join(' ');
    
    // If summary is still too long, truncate it
    if (summarizedText.length > text.length / 3) {
      summarizedText = summarizedText.slice(0, Math.floor(text.length / 3)) + '...';
    }
  } else {
    summarizedText = "Couldn't generate a summary. The text might be too short or in an unsupported format.";
  }

  return {
    id: Date.now().toString(),
    originalText: text,
    summarizedText,
    timestamp: Date.now(),
    wordCount,
    readingTime,
    sourceUrl: isUrl ? input : null
  };
};