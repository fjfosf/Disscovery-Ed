import { useState } from 'react';
import { summarizeText } from '../services/summarizer';
import { Summary } from '../types';

export const useSummarizer = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [summary, setSummary] = useState<Summary | null>(null);

  const generateSummary = async (text: string, isUrl: boolean = false) => {
    if (!text.trim()) {
      setError('Please enter some content or a URL to summarize');
      return null;
    }

    try {
      setIsLoading(true);
      setError(null);
      const result = await summarizeText(text, isUrl);
      setSummary(result);
      return result;
    } catch (err) {
      setError('Failed to generate summary. Please try again.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const clearSummary = () => {
    setSummary(null);
    setError(null);
  };

  return {
    isLoading,
    error,
    summary,
    generateSummary,
    clearSummary
  };
};