import React from 'react';
import Hero from '../components/Hero';
import SummaryForm from '../components/SummaryForm';
import SummaryResult from '../components/SummaryResult';
import { useSummarizer } from '../hooks/useSummarizer';

const HomePage = () => {
  const { isLoading, error, summary, generateSummary, clearSummary } = useSummarizer();

  return (
    <>
      {!summary && <Hero />}
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {!summary ? (
            <>
              <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6 mb-6">
                <SummaryForm onSubmit={(text) => generateSummary(text, false)} isLoading={isLoading} />
              </div>
              
              {error && (
                <div className="bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-300 p-4 rounded-lg mt-4">
                  {error}
                </div>
              )}
            </>
          ) : (
            <SummaryResult summary={summary} onReset={clearSummary} />
          )}
        </div>
      </div>
    </>
  );
};

export default HomePage;