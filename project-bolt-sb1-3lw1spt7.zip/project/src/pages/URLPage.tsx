import React from 'react';
import { Link2 } from 'lucide-react';
import SummaryForm from '../components/SummaryForm';
import SummaryResult from '../components/SummaryResult';
import { useSummarizer } from '../hooks/useSummarizer';

const URLPage = () => {
  const { isLoading, error, summary, generateSummary, clearSummary } = useSummarizer();

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 text-sm font-medium mb-4">
            <Link2 size={16} className="mr-1" />
            URL Summarizer
          </div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Summarize Discovery Education Articles
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Enter a Discovery Education URL and get an instant summary of the content.
          </p>
        </div>

        {!summary ? (
          <>
            <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6 mb-6">
              <SummaryForm onSubmit={(text) => generateSummary(text, true)} isLoading={isLoading} />
            </div>
            
            {error && (
              <div className="bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-300 p-4 rounded-lg mt-4">
                {error}
              </div>
            )}
          </>
        ) : (
          <SummaryResult summary={summary} onReset={clearSummary} />
        )}
      </div>
    </div>
  );
};

export default URLPage;